var form = document.querySelector('form')
var reset = document.querySelector('.reset')
var fname = document.querySelector("#Fname")
var lname = document.querySelector("#Lname")
var text = document.querySelector(".text")
var address = document.querySelector("#address")
var gender = document.querySelectorAll('.gender');
var option = document.querySelectorAll('.option');
var sick = document.querySelectorAll('.sick');
function validation(){
    event.preventDefault();
   if(fname.value == ""){
       alert('Type first name')
       return
   }else if(fname.value.length > 50){
    alert('Type less than 50 chracters')
    return
   }
   if(lname.value == ''){
       alert("Type last name")
       return
   }else if(lname.value.length > 50){
    alert('Type less than 50 chracters')
    return
   }
   var genderTick;
   gender.forEach(element=>{
       if(element.checked){
           genderTick = true
       }
   })
   if(!genderTick){
       alert('Select gender')
       return
   }
   if(address.value == ''){
    alert('Type address')
    return
   }else if(address.value.length > 50){
    alert('Type less than 300 chracters')
    return
   }
   var sicknessTick
   sick.forEach(el=>{
       if(el.checked){
           sicknessTick = true
       }
   })
   if(!sicknessTick){
       alert('Select Medical History')
       return
   }

   var medicalTick;
   option.forEach(element=>{
       if(element.checked){
           medicalTick = true
       }
   })
   if(!medicalTick){
       alert('Select medication')
       return
   }

   alert(`Informtion sent sucessfully ${fname.value} ${lname.value} ${address.value} ${text.value}`)

}
option.forEach(el=>{
    el.addEventListener('change', ()=>{
        if(el.value == 'yes' && text.value == ''){
            alert('Enter medication ')
            text.removeAttribute('disabled')
            return
       }else if(el.value == 'no'){
           text.value = ''
           text.setAttribute('disabled', '')
       }
    })
})
form.addEventListener('submit',validation)
